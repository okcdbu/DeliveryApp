package com.donga.deliveryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class StoreActivity extends AppCompatActivity {
    Intent getter;
    FloatingActionButton fab;
    String name, rate,Tel,Minprice,Time,tip,Category;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store);
        getter = getIntent();
        name = getter.getStringExtra("Name");
        rate = String.valueOf(getter.getDoubleExtra("Rate",0));
        Tel = getter.getStringExtra("Tel");
        Minprice = String.valueOf(getter.getIntExtra("Minprice",0));
        Time = String.valueOf(getter.getIntExtra("Time",0));
        tip = String.valueOf(getter.getIntExtra("Tip",0));
        Category = getter.getStringExtra("Category");

    }
}